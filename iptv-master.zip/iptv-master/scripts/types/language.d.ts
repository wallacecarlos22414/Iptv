export type LanguageSerializedData = {
  code: string
  name: string
}

export type LanguageData = {
  code: string
  name: string
}
