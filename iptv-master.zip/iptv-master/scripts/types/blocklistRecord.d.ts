export type BlocklistRecordData = {
  channel: string
  reason: string
  ref: string
}
