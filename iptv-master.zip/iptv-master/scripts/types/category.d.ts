export type CategorySerializedData = {
  id: string
  name: string
}

export type CategoryData = {
  id: string
  name: string
}
